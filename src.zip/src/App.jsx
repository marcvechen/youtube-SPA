import { Route, Routes } from "react-router";
import MainPage from "./MainPage";
import AuthPage from "./pages/AuthPage";
import ProtectedRoute from "./ProtectedRoute";
function App() {
  return (
    <div>
      <Routes>
        <Route path="/login" element={<AuthPage />} />
        <Route element={<ProtectedRoute />}>
          <Route index path="/" element={<MainPage />} />
        </Route>
      </Routes>
    </div>
  );
}

export default App;
