import { Button, Input, Tabs } from "antd";
import { Navigate } from "react-router";
import axios from "axios";
import "./style/MainPage.css";
function MainPage() {
  const { Search } = Input;
  const handleLogOut = () => {
    localStorage.removeItem("access_token");
    <Navigate to="/login" />;
  };
  const onChange = (key) => {
    console.log(key);
  };
  const items = [
    {
      key: "1",
      label: "Search",
    },
    {
      key: "2",
      label: "Favorites",
    },
  ];
  return (
    <div className="mainDiv">
      <div className="innerDiv">
        <div className="header">
          <Tabs defaultActiveKey="1" items={items} onChange={onChange} />

          <Button onClick={handleLogOut}>Log out</Button>
        </div>
        <div>
          <Search placeholder="Search" enterButton="🔍" size="large" />
        </div>
      </div>
    </div>
  );
}
export default MainPage;
