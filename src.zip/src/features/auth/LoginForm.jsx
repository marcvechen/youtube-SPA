import axios from "axios";
import { useForm } from "react-hook-form";
import { Button, Input } from "antd";
import { useNavigate } from "react-router";
function LoginForm() {
  const {
    register,
    setError,
    handleSubmit,
    formState: { errors },
  } = useForm();
  const navigate = useNavigate();
  const onSubmit = async (data) => {
    try {
      const response = await axios.post(
        "https://todo-redev.onrender.com/api/auth/login",
        {
          data,
        },
      );
      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.message || "Login error");
      }
      localStorage.setItem("access_token", result.access_token);
      navigate("/");
    } catch (error) {
      setError("root.serverError", {
        type: "manual",
        message: error.message,
      });
    }
  };
  return (
    <div style={{ display: "flex", justifyContent: "center" }}>
      <form
        style={{
          margin: 150,
          display: "flex",
          alignItems: "center",
          flexDirection: "column",
          gap: 15,
        }}
        onSubmit={handleSubmit(onSubmit)}
      >
        <h3>Login</h3>
        <Input
          placeholder="Email"
          {...register("email", {
            required: "Required field",
            pattern: {
              value: /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/,
              message: "Write corrent an email",
            },
          })}
        />
        {errors.email && <p style={{ color: "red" }}>{errors.email.message}</p>}
        <Input.Password
          type="password"
          placeholder="password"
          {...register("password", {
            required: "Required field",
            validate: (value) =>
              /^(?=.*[A-Z]).{6,}$/.test(value) || "Password is too weak",
          })}
        />
        {errors.password && (
          <p style={{ color: "red" }}>{errors.password.message}</p>
        )}
        <Button color="primary" variant="solid" type="submit">
          Login
        </Button>
      </form>
    </div>
  );
}
export default LoginForm;
