import axios from "axios";
import { useForm } from "react-hook-form";
import { Button, Input } from "antd";
import { useNavigate } from "react-router";

function RegisterForm() {
  const {
    register,
    setError,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm();
  const navigate = useNavigate();
  const passwordWatch = watch("password");
  const onSubmit = async (data) => {
    try {
      const response = await axios.post(
        `https://todo-redev.onrender.com/api/auth/register`,
        data,
      );

      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.message || "Registration error");
      }
      localStorage.setItem("access_token", result.access_token);
      navigate("/");
    } catch (error) {
      setError("root.serverError", {
        type: "manual",
        message: error.message,
      });
    }
  };
  return (
    <div style={{ display: "flex", justifyContent: "center" }}>
      <form
        style={{
          margin: 150,
          display: "flex",
          alignItems: "center",
          flexDirection: "column",
          gap: 15,
        }}
        onSubmit={handleSubmit(onSubmit)}
      >
        <h3>Register</h3>
        <Input placeholder="Name" required />
        <Input
          placeholder="Email"
          {...register("email", {
            required: "Required field",
            pattern: {
              value: /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/,
              message: "Write corrent an email",
            },
          })}
        />
        {errors.email && <p style={{ color: "red" }}>{errors.email.message}</p>}

        <Input.Password
          type="password"
          placeholder="password"
          {...register("password", {
            required: "Required field",
            validate: (value) =>
              /^(?=.*[A-Z]).{6,}$/.test(value) || "Password is too weak",
          })}
        />
        {errors.password && (
          <p style={{ color: "red" }}>{errors.password.message}</p>
        )}
        <Input.Password
          type="password"
          placeholder="Confirm password"
          {...register("confirmPassword", {
            required: "Required field",
            validate: (value) =>
              value === passwordWatch || "Password should be same",
          })}
        />
        {errors.confirmPassword && (
          <p style={{ color: "red" }}>{errors.confirmPassword.message}</p>
        )}
        <Button color="primary" variant="solid" type="sumbit">
          Register
        </Button>
      </form>
    </div>
  );
}
export default RegisterForm;
